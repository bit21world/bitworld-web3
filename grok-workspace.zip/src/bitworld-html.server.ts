import html from "./bitworld.html?raw";

export const BITWORLD_HTML = html;
