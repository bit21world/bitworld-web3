import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/register")({
  server: {
    handlers: {
      GET: async () => Response.json({ ok: true }),
    },
  },
});
