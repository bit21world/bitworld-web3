import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  server: {
    handlers: {
      GET: async () => {
        const { BITWORLD_HTML } = await import("../bitworld-html.server");
        return new Response(BITWORLD_HTML, {
          headers: {
            "content-type": "text/html; charset=utf-8",
            "cache-control": "no-cache",
          },
        });
      },
    },
  },
  component: Home,
});

function Home() {
  return (
    <main className="grid min-h-dvh place-items-center bg-[#06163a] px-6 text-center text-[#e8ecf5]">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#22d3ee]">Bitworld</p>
        <h1 className="mt-2 text-4xl font-extrabold text-[#f5b82e]">BTW</h1>
      </div>
    </main>
  );
}
