//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CldXaVFV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/api/me",
			"/api/register"
		],
		preloads: ["/assets/index-D_wF29nN.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D_wF29nN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-YPtdpiEN.js"]
	}
} });
//#endregion
export { tsrStartManifest };
